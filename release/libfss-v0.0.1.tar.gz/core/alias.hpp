
#pragma once

#include <filesystem>

namespace fss
{
    using AddFunc = std::true_type;

    using SubFunc = std::false_type;

    using uvector = std::vector<uint64_t>;

    using dvector = std::vector<double>;

    using umatrix = std::vector<uvector>;

    using dmatrix = std::vector<dvector>;

    template <typename T>
    using pair_of = std::pair<T, T>;
}