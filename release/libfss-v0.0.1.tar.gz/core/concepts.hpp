
#pragma once

#include "core/alias.hpp"
#include "core/trait.hpp"

namespace fss
{
    template <typename T>
    concept Integral = std::is_integral_v<T>;

    template <typename T>
    concept FloatingPoint = std::is_floating_point_v<T>;

    template <typename T>
    concept UnsignedIntegral = Integral<T> and std::is_unsigned_v<T>;

//    template <typename T>
//    concept String = is_std_basic_string_v<T>;
}