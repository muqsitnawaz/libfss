
#pragma once

#include <tuple>

#include "util/hash.hpp"

namespace std
{
    template <typename S, typename T>
    struct hash<std::pair<S, T>>
    {
        inline size_t operator()(const std::pair<S, T>& val) const
        {
            size_t seed = 0;
            otak::HashUtils::combine(seed, val.first);
            otak::HashUtils::combine(seed, val.second);
            return seed;
        }
    };
}