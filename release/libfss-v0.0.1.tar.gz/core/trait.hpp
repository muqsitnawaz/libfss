
#pragma once

#include <type_traits>

namespace fss
{
    template <typename T, template <typename...> typename Template>
    struct is_specialization_of : std::false_type {};

    template <template <typename...> typename Template, typename... Args>
    struct is_specialization_of<Template<Args...>, Template> : std::true_type {};

    template <typename>
    struct is_std_basic_string : std::false_type {};

//    template <typename C, typename T, typename A>
//    struct is_std_basic_string<std::basic_string<C, T, A>> : std::true_type {};
//
//    template <typename T>
//    inline constexpr bool is_std_basic_string_v = is_std_basic_string<T>::value;
}