
#include "fssevaluator.hpp"

namespace fss {
    uint64_t FSSEvaluator::relu(const ReLUKey &relu_key, uint64_t blinded_input) {
        auto f1 = eval_dif_internal(relu_key.f[0], blinded_input) % plain_modulus_.value();
        auto f2 = eval_dif_internal(relu_key.f[1], blinded_input) % plain_modulus_.value();
        auto f3 = eval_dif_internal(relu_key.f[2], blinded_input) % plain_modulus_.value();

        auto g1 = eval_dif_internal(relu_key.g[0], blinded_input) % plain_modulus_.value();
        auto g2 = eval_dif_internal(relu_key.g[1], blinded_input) % plain_modulus_.value();
        auto g3 = eval_dif_internal(relu_key.g[2], blinded_input) % plain_modulus_.value();

        auto c0 = add_uint_uint_mod(add_uint_uint_mod(f1, f2, plain_modulus_), f3, plain_modulus_);
        auto c1 = add_uint_uint_mod(add_uint_uint_mod(g1, g2, plain_modulus_), g3, plain_modulus_);
        auto y = add_uint_uint_mod(multiply_uint_uint_mod(blinded_input, c0, plain_modulus_), c1, plain_modulus_);

        return y % plain_modulus_.value();
    }

    uint64_t FSSEvaluator::tanh(const SplineKey &tanh_key, uint64_t blinded_input) {
        auto f1 = eval_dif_spline_internal(tanh_key.f[0], blinded_input);
        auto f2 = eval_dif_spline_internal(tanh_key.f[1], blinded_input);
        auto f3 = eval_dif_spline_internal(tanh_key.f[2], blinded_input);
        auto f4 = eval_dif_spline_internal(tanh_key.f[3], blinded_input);
        auto f5 = eval_dif_spline_internal(tanh_key.f[4], blinded_input);
        auto f6 = eval_dif_spline_internal(tanh_key.f[5], blinded_input);
        auto f7 = eval_dif_spline_internal(tanh_key.f[6], blinded_input);
        auto f8 = eval_dif_spline_internal(tanh_key.f[7], blinded_input);

        auto g1 = eval_dif_spline_internal(tanh_key.g[0], blinded_input);
        auto g2 = eval_dif_spline_internal(tanh_key.g[1], blinded_input);
        auto g3 = eval_dif_spline_internal(tanh_key.g[2], blinded_input);
        auto g4 = eval_dif_spline_internal(tanh_key.g[3], blinded_input);
        auto g5 = eval_dif_spline_internal(tanh_key.g[4], blinded_input);
        auto g6 = eval_dif_spline_internal(tanh_key.g[5], blinded_input);
        auto g7 = eval_dif_spline_internal(tanh_key.g[6], blinded_input);
        auto g8 = eval_dif_spline_internal(tanh_key.g[7], blinded_input);

        auto c0 = add_uint_uint_mod(add_uint_uint_mod(f1, f2, plain_modulus_spline_), f3, plain_modulus_spline_);
        c0 = add_uint_uint_mod(add_uint_uint_mod(c0, f4, plain_modulus_spline_), f5, plain_modulus_spline_);
        c0 = add_uint_uint_mod(add_uint_uint_mod(add_uint_uint_mod(c0, f6, plain_modulus_spline_), f7,
                                                 plain_modulus_spline_), f8, plain_modulus_spline_);
        auto c1 = add_uint_uint_mod(add_uint_uint_mod(g1, g2, plain_modulus_spline_), g3, plain_modulus_spline_);
        c1 = add_uint_uint_mod(add_uint_uint_mod(c1, g4, plain_modulus_spline_), g5, plain_modulus_spline_);
        c1 = add_uint_uint_mod(add_uint_uint_mod(add_uint_uint_mod(c1, g6, plain_modulus_spline_), g7,
                                                 plain_modulus_spline_), g8, plain_modulus_spline_);
        auto y = add_uint_uint_mod(multiply_uint_uint_mod(blinded_input, c0, plain_modulus_spline_), c1,
                                   plain_modulus_spline_);

        return y >> 5;
    }

    uint64_t FSSEvaluator::sigmoid(const SplineKey &sigmoid_key, uint64_t blinded_input) {
        auto f1 = eval_dif_spline_internal(sigmoid_key.f[0], blinded_input);
        auto f2 = eval_dif_spline_internal(sigmoid_key.f[1], blinded_input);
        auto f3 = eval_dif_spline_internal(sigmoid_key.f[2], blinded_input);
        auto f4 = eval_dif_spline_internal(sigmoid_key.f[3], blinded_input);
        auto f5 = eval_dif_spline_internal(sigmoid_key.f[4], blinded_input);
        auto f6 = eval_dif_spline_internal(sigmoid_key.f[5], blinded_input);
        auto f7 = eval_dif_spline_internal(sigmoid_key.f[6], blinded_input);
        auto f8 = eval_dif_spline_internal(sigmoid_key.f[7], blinded_input);

        auto g1 = eval_dif_spline_internal(sigmoid_key.g[0], blinded_input);
        auto g2 = eval_dif_spline_internal(sigmoid_key.g[1], blinded_input);
        auto g3 = eval_dif_spline_internal(sigmoid_key.g[2], blinded_input);
        auto g4 = eval_dif_spline_internal(sigmoid_key.g[3], blinded_input);
        auto g5 = eval_dif_spline_internal(sigmoid_key.g[4], blinded_input);
        auto g6 = eval_dif_spline_internal(sigmoid_key.g[5], blinded_input);
        auto g7 = eval_dif_spline_internal(sigmoid_key.g[6], blinded_input);
        auto g8 = eval_dif_spline_internal(sigmoid_key.g[7], blinded_input);

        auto c0 = add_uint_uint_mod(add_uint_uint_mod(f1, f2, plain_modulus_spline_), f3, plain_modulus_spline_);
        c0 = add_uint_uint_mod(add_uint_uint_mod(c0, f4, plain_modulus_spline_), f5, plain_modulus_spline_);
        c0 = add_uint_uint_mod(add_uint_uint_mod(add_uint_uint_mod(c0, f6, plain_modulus_spline_), f7,
                                                 plain_modulus_spline_), f8, plain_modulus_spline_);
        auto c1 = add_uint_uint_mod(add_uint_uint_mod(g1, g2, plain_modulus_spline_), g3, plain_modulus_spline_);
        c1 = add_uint_uint_mod(add_uint_uint_mod(c1, g4, plain_modulus_spline_), g5, plain_modulus_spline_);
        c1 = add_uint_uint_mod(add_uint_uint_mod(add_uint_uint_mod(c1, g6, plain_modulus_spline_), g7,
                                                 plain_modulus_spline_), g8, plain_modulus_spline_);
        if (2 * blinded_input > plain_modulus_.value()) {
            blinded_input = plain_modulus_spline_.value() - plain_modulus_.value() + blinded_input;
        }
        auto y = add_uint_uint_mod(multiply_uint_uint_mod(blinded_input, c0, plain_modulus_spline_), c1,
                                   plain_modulus_spline_);

        return (y >> 5) % plain_modulus_.value();
    }

    uint64_t FSSEvaluator::eval_max2_outer_coeffs_internal(const Max2Key &k, uint64_t x,
                                                           uint64_t y, uint64_t relu_sum, uint64_t relu_diff) {
        auto f1 = eval_dpf_internal(k.f[0], relu_sum);
        auto f2 = eval_dpf_internal(k.f[1],
                                    sub_uint_uint_mod(relu_sum, add_uint_uint_mod(x, y, plain_modulus_),
                                                      plain_modulus_));
        auto f3 = eval_dpf_internal(k.f[2], relu_sum);
        auto f4 = eval_dpf_internal(k.f[3],
                                    sub_uint_uint_mod(relu_sum, add_uint_uint_mod(x, y, plain_modulus_),
                                                      plain_modulus_));

        auto sign = add_uint_uint_mod(f1, f2, plain_modulus_);
        auto offset = add_uint_uint_mod(add_uint_uint_mod(f3, f4, plain_modulus_), k.r, plain_modulus_);
        auto not_sign = sub_uint_uint_mod(server_id_, sign, plain_modulus_);

        auto output = multiply_uint_uint_mod(sign, relu_diff, plain_modulus_);
        output = add_uint_uint_mod(output, multiply_uint_uint_mod(not_sign, relu_sum, plain_modulus_),
                                   plain_modulus_);
        output = add_uint_uint_mod(output, offset, plain_modulus_);

        return output;
    }

    uint64_t FSSEvaluator::eval_max2_relu_sum_internal(const Max2Key &k, uint64_t x, uint64_t y) {
        auto x_masked = x % plain_modulus_.value();
        auto y_masked = y % plain_modulus_.value();

        auto f21 = eval_dif_internal(k.f2[0], x_masked) % plain_modulus_.value();
        auto f22 = eval_dif_internal(k.f2[1], x_masked) % plain_modulus_.value();
        auto f23 = eval_dif_internal(k.f2[2], x_masked) % plain_modulus_.value();
        auto g21 = eval_dif_internal(k.g2[0], x_masked) % plain_modulus_.value();
        auto g22 = eval_dif_internal(k.g2[1], x_masked) % plain_modulus_.value();
        auto g23 = eval_dif_internal(k.g2[2], x_masked) % plain_modulus_.value();

        auto f31 = eval_dif_internal(k.f3[0], y_masked) % plain_modulus_.value();
        auto f32 = eval_dif_internal(k.f3[1], y_masked) % plain_modulus_.value();
        auto f33 = eval_dif_internal(k.f3[2], y_masked) % plain_modulus_.value();
        auto g31 = eval_dif_internal(k.g3[0], y_masked) % plain_modulus_.value();
        auto g32 = eval_dif_internal(k.g3[1], y_masked) % plain_modulus_.value();
        auto g33 = eval_dif_internal(k.g3[2], y_masked) % plain_modulus_.value();

        auto f2c0 = add_uint_uint_mod(add_uint_uint_mod(f21, f22, plain_modulus_), f23, plain_modulus_);
        auto f2c1 = add_uint_uint_mod(add_uint_uint_mod(g21, g22, plain_modulus_), g23, plain_modulus_);
        auto f2z = add_uint_uint_mod(multiply_uint_uint_mod(x_masked, f2c0, plain_modulus_), f2c1, plain_modulus_);
        f2z = f2z % plain_modulus_.value();

        auto f3c0 = add_uint_uint_mod(add_uint_uint_mod(f31, f32, plain_modulus_), f33, plain_modulus_);
        auto f3c1 = add_uint_uint_mod(add_uint_uint_mod(g31, g32, plain_modulus_), g33, plain_modulus_);
        auto f3z = add_uint_uint_mod(multiply_uint_uint_mod(y_masked, f3c0, plain_modulus_), f3c1, plain_modulus_);
        f3z = f3z % plain_modulus_.value();

        return add_uint_uint_mod(f2z, f3z, plain_modulus_);
    }

    uint64_t FSSEvaluator::eval_max2_relu_diff_internal(const Max2Key &k, uint64_t x, uint64_t y, uint64_t y_share) {
        auto xy_masked = sub_uint_uint_mod(x, y, plain_modulus_);

        auto f11 = eval_dif_internal(k.f1[0], xy_masked) % plain_modulus_.value();
        auto f12 = eval_dif_internal(k.f1[1], xy_masked) % plain_modulus_.value();
        auto f13 = eval_dif_internal(k.f1[2], xy_masked) % plain_modulus_.value();
        auto g11 = eval_dif_internal(k.g1[0], xy_masked) % plain_modulus_.value();
        auto g12 = eval_dif_internal(k.g1[1], xy_masked) % plain_modulus_.value();
        auto g13 = eval_dif_internal(k.g1[2], xy_masked) % plain_modulus_.value();

        auto f1c0 = add_uint_uint_mod(add_uint_uint_mod(f11, f12, plain_modulus_), f13, plain_modulus_);
        auto f1c1 = add_uint_uint_mod(add_uint_uint_mod(g11, g12, plain_modulus_), g13, plain_modulus_);
        auto f1z = add_uint_uint_mod(multiply_uint_uint_mod(xy_masked, f1c0, plain_modulus_), f1c1,
                                     plain_modulus_);

        return add_uint_uint_mod(y_share, f1z, plain_modulus_);
    }

    void FSSEvaluator::evaluate_maxpool_layer_inner_coeffs(const MaxPoolKey &k, uint64_t *x,
                                                           uint64_t *x_share, uint64_t rowsize, uint64_t *relu_sum,
                                                           uint64_t *relu_diff) {
        uint64_t num = k.pool_size;
        uint32_t row_id = 0;
        uint64_t k_index = 0;

        uint64_t rows = fast_floor_log2(k.pool_size);
        uint64_t row_sizes[rows + 1];
        while (rows != 0) {
            row_sizes[rows--] = num;
            num = num / 2 + num % 2;
        }
        row_sizes[0] = 0;
        while (row_sizes[row_id] != rowsize) {
            k_index += row_sizes[row_id] / 2;
            row_id++;
        }
        for (size_t i = 0; i < rowsize / 2; i++) {
            relu_sum[i] = eval_max2_relu_sum_internal(k.f[k_index + i], x[2 * i],
                                                      x[2 * i + 1]) % plain_modulus_.value();
            relu_diff[i] = eval_max2_relu_diff_internal(k.f[k_index + i], x[2 * i],
                                                        x[2 * i + 1], x_share[2 * i + 1]) % plain_modulus_.value();
        }
    }

    void FSSEvaluator::evaluate_maxpool_layer_outer_coeffs(const MaxPoolKey &k, uint64_t *x,
                                                           uint64_t *relu_sum, uint64_t *relu_diff, uint64_t rowsize,
                                                           uint64_t *output) {
        uint64_t num = k.pool_size;
        uint32_t row_id = 0;
        uint64_t k_index = 0;
        uint64_t rows = fast_floor_log2(k.pool_size);
        uint64_t row_sizes[rows + 1];
        while (rows != 0) {
            row_sizes[rows--] = num;
            num = num / 2 + num % 2;
        }
        row_sizes[0] = 0;
        while (row_sizes[row_id] != rowsize) {
            k_index += row_sizes[row_id] / 2;
            row_id++;
        }
        for (size_t i = 0; i < rowsize / 2; i++) {
            output[i] = eval_max2_outer_coeffs_internal(k.f[k_index + i], x[2 * i], x[2 * i + 1], relu_sum[i],
                                                        relu_diff[i]) % plain_modulus_.value();
        }
    }

    uint64_t FSSEvaluator::eval_dpf_internal(const DPFKey &k, uint64_t x) {
        // start at the correct LSB
        int xi;
        u_char s[16];
        u_char t;

        u_char sArray[32];
        u_char temp[2];
        u_char out[48];
        u_char tau[48];
        memcpy(s, k.s, 16);
        t = server_id_;
        for (uint32_t i = 0; i < num_bits_; i++) {
            prf_->generate(s, 48, out);
            memcpy(sArray, out, 32);
            temp[0] = out[32] % 2;
            temp[1] = out[33] % 2;
            if (t == 0) {
                for (uint32_t j = 0; j < 16; j++) {
                    tau[j] = sArray[j];
                }
                for (uint32_t j = 0; j < 16; j++) {
                    tau[j + 16] = sArray[j + 16];
                }
                tau[32] = temp[0];
                tau[33] = temp[1];
            } else {
                for (uint32_t j = 0; j < 16; j++) {
                    tau[j] = sArray[j] ^ k.cw[i].cs[j];
                }
                for (uint32_t j = 0; j < 16; j++) {
                    tau[j + 16] = sArray[j + 16] ^ k.cw[i].cs[j];
                }
                tau[32] = temp[0] ^ k.cw[i].ct[0];
                tau[33] = temp[1] ^ k.cw[i].ct[1];
            }
            xi = get_bit(x, (64 - num_bits_ + i + 1));
            if (xi == 0) {
                memcpy(s, tau, 16);
                t = tau[32];
            } else {
                memcpy(s, tau + 16, 16);
                t = tau[33];
            }
        }
        uint64_t ans;

        ans = (uint64_t) s[0] << 56 |
              (uint64_t) s[1] << 48 |
              (uint64_t) s[2] << 40 |
              (uint64_t) s[3] << 32 |
              (uint64_t) s[4] << 24 |
              (uint64_t) s[5] << 16 |
              (uint64_t) s[6] << 8 |
              (uint64_t) s[7];
        ans = ans % plain_modulus_.value();
        ans = add_uint_uint_mod(ans, multiply_uint_uint_mod(t, k.cw_last, plain_modulus_), plain_modulus_);
        if (!server_id_) {
            ans = seal::util::negate_uint_mod(ans, plain_modulus_);
        }
        return ans;
    }

    uint64_t FSSEvaluator::eval_dif_internal(const DIFKey &k, uint64_t x) {
        u_char s[16];
        memcpy(s, k.s, 16);
        u_char t = k.t;
        uint64_t v = 0;

        u_char sArray[32];
        u_char temp[2];
        u_char out[64];
        uint64_t temp_v;

        for (size_t i = 0; i < num_bits_; i++) {
            auto xi = get_bit(x, (64 - num_bits_ + i + 1));

            // Generate PRF.
            prf_->generate(s, 64, out);

            memcpy(sArray, out, 32);
            temp[0] = out[32] % 2;
            temp[1] = out[33] % 2;

            temp_v = byte_array_to_integer((u_char *) (out + 40 + (8 * xi))) % plain_modulus_.value();

            auto xStart = 16 * xi;
            memcpy(s, (u_char *) (sArray + xStart), 16);

            for (size_t j = 0; j < 16; j++) {
                s[j] = s[j] ^ (k.cw[i].cs[j] * t);
            }

            v = add_uint_uint_mod(v, temp_v, plain_modulus_);
            v = add_uint_uint_mod(v, k.cw[i].cv[xi] * t, plain_modulus_);

            t = temp[xi] ^ (k.cw[i].ct[xi] * t);
        }

        if (server_id_) {
            v = negate_uint_mod(v, plain_modulus_);
        }

        return v % plain_modulus_.value();
    }

    uint64_t FSSEvaluator::eval_dif_spline_internal(const DIFKey &k, uint64_t x) {
        u_char s[16];
        memcpy(s, k.s, 16);
        u_char t = k.t;
        uint64_t v = 0;

        u_char sArray[32];
        u_char temp[2];
        u_char out[64];
        uint64_t temp_v;

        for (size_t i = 0; i < num_bits_; i++) {
            auto xi = get_bit(x, (64 - num_bits_ + i + 1));

            // Generate PRF.
            prf_->generate(s, 64, out);

            memcpy(sArray, out, 32);
            temp[0] = out[32] % 2;
            temp[1] = out[33] % 2;

            temp_v = byte_array_to_integer((u_char *) (out + 40 + (8 * xi))) % plain_modulus_spline_.value();

            auto xStart = 16 * xi;
            memcpy(s, (u_char *) (sArray + xStart), 16);

            for (size_t j = 0; j < 16; j++) {
                s[j] = s[j] ^ (k.cw[i].cs[j] * t);
            }

            v = add_uint_uint_mod(v, temp_v, plain_modulus_spline_);
            v = add_uint_uint_mod(v, k.cw[i].cv[xi] * t, plain_modulus_spline_);

            t = temp[xi] ^ (k.cw[i].ct[xi] * t);
        }

        if (server_id_) {
            v = negate_uint_mod(v, plain_modulus_spline_);
        }

        return v % plain_modulus_spline_.value();
    }

#ifdef FSS_ENABLE_MPC
    uint64_t FSSEvaluator::relu_mpc(const ReLUKeyMPC& relu_key, uint64_t blinded_input)
    {
        auto f1 = eval_dif_internal_mpc(relu_key.f[0], blinded_input) % plain_modulus_.value();
        auto f2 = eval_dif_internal_mpc(relu_key.f[1], blinded_input) % plain_modulus_.value();
        auto f3 = eval_dif_internal_mpc(relu_key.f[2], blinded_input) % plain_modulus_.value();

        auto g1 = eval_dif_internal_mpc(relu_key.g[0], blinded_input) % plain_modulus_.value();
        auto g2 = eval_dif_internal_mpc(relu_key.g[1], blinded_input) % plain_modulus_.value();
        auto g3 = eval_dif_internal_mpc(relu_key.g[2], blinded_input) % plain_modulus_.value();

        auto c0 = add_uint_uint_mod(add_uint_uint_mod(f1, f2, plain_modulus_), f3, plain_modulus_);
        auto c1 = add_uint_uint_mod(add_uint_uint_mod(g1, g2, plain_modulus_), g3, plain_modulus_);
        auto y = add_uint_uint_mod(multiply_uint_uint_mod(blinded_input, c0, plain_modulus_), c1, plain_modulus_);

        return y % plain_modulus_.value();
    }

    uint64_t FSSEvaluator::tanh_mpc(const SplineKeyMPC& tanh_key, uint64_t blinded_input)
    {
        auto f1 = eval_dif_internal_mpc(tanh_key.f[0], blinded_input);
        auto f2 = eval_dif_internal_mpc(tanh_key.f[1], blinded_input);
        auto f3 = eval_dif_internal_mpc(tanh_key.f[2], blinded_input);
        auto f4 = eval_dif_internal_mpc(tanh_key.f[3], blinded_input);
        auto f5 = eval_dif_internal_mpc(tanh_key.f[4], blinded_input);
        auto f6 = eval_dif_internal_mpc(tanh_key.f[5], blinded_input);
        auto f7 = eval_dif_internal_mpc(tanh_key.f[6], blinded_input);
        auto f8 = eval_dif_internal_mpc(tanh_key.f[7], blinded_input);

        auto g1 = eval_dif_internal_mpc(tanh_key.g[0], blinded_input);
        auto g2 = eval_dif_internal_mpc(tanh_key.g[1], blinded_input);
        auto g3 = eval_dif_internal_mpc(tanh_key.g[2], blinded_input);
        auto g4 = eval_dif_internal_mpc(tanh_key.g[3], blinded_input);
        auto g5 = eval_dif_internal_mpc(tanh_key.g[4], blinded_input);
        auto g6 = eval_dif_internal_mpc(tanh_key.g[5], blinded_input);
        auto g7 = eval_dif_internal_mpc(tanh_key.g[6], blinded_input);
        auto g8 = eval_dif_internal_mpc(tanh_key.g[7], blinded_input);

        auto c0 = add_uint_uint_mod(add_uint_uint_mod(f1, f2, plain_modulus_spline_), f3, plain_modulus_spline_);
        c0 = add_uint_uint_mod(add_uint_uint_mod(c0, f4, plain_modulus_spline_), f5, plain_modulus_spline_);
        c0 = add_uint_uint_mod(add_uint_uint_mod(add_uint_uint_mod(c0, f6, plain_modulus_spline_), f7,
                plain_modulus_spline_), f8, plain_modulus_spline_);
        auto c1 = add_uint_uint_mod(add_uint_uint_mod(g1, g2, plain_modulus_spline_), g3, plain_modulus_spline_);
        c1 = add_uint_uint_mod(add_uint_uint_mod(c1, g4, plain_modulus_spline_), g5, plain_modulus_spline_);
        c1 = add_uint_uint_mod(add_uint_uint_mod(add_uint_uint_mod(c1, g6, plain_modulus_spline_), g7,
                plain_modulus_spline_), g8, plain_modulus_spline_);
        auto y = add_uint_uint_mod(multiply_uint_uint_mod(blinded_input, c0, plain_modulus_spline_), c1,
                plain_modulus_spline_);

        return y >> 5;
    }

    uint64_t FSSEvaluator::eval_dpf_internal_mpc(const DPFKeyMPC &k, uint64_t x)
    {
        // start at the correct LSB
        int xi;
        u_char s[48];
        u_char t;

        u_char sArray[96];
        u_char temp[2];
        u_char out[112];
        u_char out0[112];
        u_char out1[112];
        u_char out2[112];
        u_char tau[112];
        memcpy(s, k.s, 48);
        t = server_id_;
        for (uint32_t i = 0; i < num_bits_; i++)
        {
            prf_->generate(s, 112, out0);
            prf_->generate(s + 16, 112, out1);
            prf_->generate(s + 32, 112, out2);

            for (size_t prf_index = 0; prf_index < 112; prf_index++)
            {
                out[prf_index] = out0[prf_index] ^ out1[prf_index] ^ out2[prf_index];
            }

            memcpy(sArray, out, 96);
            temp[0] = out[96] % 2;
            temp[1] = out[97] % 2;
            if (t == 0)
            {
                for (uint32_t j = 0; j < 48; j++)
                {
                    tau[j] = sArray[j];
                }
                for (uint32_t j = 0; j < 48; j++)
                {
                    tau[j + 48] = sArray[j + 48];
                }
                tau[96] = temp[0];
                tau[97] = temp[1];
            }
            else
            {
                for (uint32_t j = 0; j < 48; j++)
                {
                    tau[j] = sArray[j] ^ k.cw[i].cs[j];
                }
                for (uint32_t j = 0; j < 48; j++)
                {
                    tau[j + 48] = sArray[j + 48] ^ k.cw[i].cs[j];
                }
                tau[96] = temp[0] ^ k.cw[i].ct[0];
                tau[97] = temp[1] ^ k.cw[i].ct[1];
            }
            xi = get_bit(x, (64 - num_bits_ + i + 1));
            if (xi == 0)
            {
                memcpy(s, tau, 48);
                t = tau[96];
            }
            else
            {
                memcpy(s, tau + 48, 48);
                t = tau[97];
            }
        }
        uint64_t ans, ans0, ans1, ans2;

        ans0 = (uint64_t) s[0] << 56 |
               (uint64_t) s[1] << 48 |
               (uint64_t) s[2] << 40 |
               (uint64_t) s[3] << 32 |
               (uint64_t) s[4] << 24 |
               (uint64_t) s[5] << 16 |
               (uint64_t) s[6] << 8 |
               (uint64_t) s[7];

        ans1 = (uint64_t) s[0 + 16] << 56 |
               (uint64_t) s[1 + 16] << 48 |
               (uint64_t) s[2 + 16] << 40 |
               (uint64_t) s[3 + 16] << 32 |
               (uint64_t) s[4 + 16] << 24 |
               (uint64_t) s[5 + 16] << 16 |
               (uint64_t) s[6 + 16] << 8 |
               (uint64_t) s[7 + 16];

        ans2 = (uint64_t) s[0 + 32] << 56 |
               (uint64_t) s[1 + 32] << 48 |
               (uint64_t) s[2 + 32] << 40 |
               (uint64_t) s[3 + 32] << 32 |
               (uint64_t) s[4 + 32] << 24 |
               (uint64_t) s[5 + 32] << 16 |
               (uint64_t) s[6 + 32] << 8 |
               (uint64_t) s[7 + 32];

        ans0 = ans0 % plain_modulus_.value();
        ans1 = ans1 % plain_modulus_.value();
        ans2 = ans2 % plain_modulus_.value();

        ans = add_uint_uint_mod(add_uint_uint_mod(ans0, ans1, plain_modulus_), ans2, plain_modulus_);
        ans = add_uint_uint_mod(ans, multiply_uint_uint_mod(t, k.cw_last, plain_modulus_), plain_modulus_);
        if (!server_id_)
        {
            ans = negate_uint_mod(ans, plain_modulus_);
        }
        return ans;
    }

    uint64_t FSSEvaluator::eval_dif_internal_mpc(const DIFKeyMPC& k, uint64_t x)
    {
        u_char s[48];
        memcpy(s, k.s, 48);
        u_char t = k.t;
        uint64_t v = 0;

        u_char sArray[96];
        u_char temp[2];
        u_char out[128];
        u_char out0[128];
        u_char out1[128];
        u_char out2[128];
        uint64_t temp_v;
        uint64_t temp_v0;
        uint64_t temp_v1;
        uint64_t temp_v2;

        for (size_t i = 0; i < num_bits_; i++)
        {
            auto xi = get_bit(x, (64 - num_bits_ + i + 1));

            // Generate PRF.
            prf_->generate(s, 128, out0);
            prf_->generate(s + 16, 128, out1);
            prf_->generate(s + 32, 128, out2);

            for (size_t prf_index = 0; prf_index < 112; prf_index++)
            {
                out[prf_index] = out0[prf_index] ^ out1[prf_index] ^ out2[prf_index];
            }

            temp_v0 = byte_array_to_integer((u_char *) (out0 + 112 + (8 * xi))) % plain_modulus_.value();
            temp_v1 = byte_array_to_integer((u_char *) (out1 + 112 + (8 * xi))) % plain_modulus_.value();
            temp_v2 = byte_array_to_integer((u_char *) (out2 + 112 + (8 * xi))) % plain_modulus_.value();

            temp_v = add_uint_uint_mod(add_uint_uint_mod(temp_v0, temp_v1, plain_modulus_), temp_v2, plain_modulus_);
            memcpy(sArray, out, 96);
            temp[0] = out[96] % 2;
            temp[1] = out[97] % 2;

            auto xStart = 48 * xi;
            memcpy(s, (u_char *) (sArray + xStart), 48);

            for (size_t j = 0; j < 48; j++)
            {
                s[j] = s[j] ^ (k.cw[i].cs[j] * t);
            }

            v = add_uint_uint_mod(v, temp_v, plain_modulus_);
            v = add_uint_uint_mod(v, k.cw[i].cv[xi] * t, plain_modulus_);

            t = temp[xi] ^ (k.cw[i].ct[xi] * t);
        }

        if (server_id_)
        {
            v = negate_uint_mod(v, plain_modulus_);
        }

        return v % plain_modulus_.value();
    }
#endif FSS_ENABLE_MPC
}
