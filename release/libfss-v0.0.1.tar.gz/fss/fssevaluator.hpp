
#pragma once

#include <cmath>

#include <fss/common.hpp>
#include <fss/keys.hpp>
#include <fss/expandingprf.hpp>
#include <fss/fsscontext.hpp>

#include "seal/uintarithsmallmod.h"

using namespace seal::util;

namespace fss {
    class FSSEvaluator {
    public:
        /**
         * Constructs an FSSEvaluator instance with the given FSSContext.
         *
         * @param fss_context The given FSSContext.
         */
        explicit FSSEvaluator(const std::shared_ptr<FSSContext> &fss_context, size_t server_id) {
            // Verify parameters.
            if (!fss_context) {
                throw std::invalid_argument("Invalid FSSContext.");
            }

            fss_context_ = fss_context;
            prf_ = std::make_unique<ExpandingPRF>(fss_context);

            num_bits_ = fss_context_->num_bits();
            plain_modulus_ = fss_context_->plain_modulus();
            plain_modulus_spline_ = SmallModulus(plain_modulus_.value() << 5u);
            server_id_ = server_id;
            scaling_ = fss_context_->scaling();
        }

        uint64_t relu(const ReLUKey &relu_key, uint64_t blinded_input);

        uint64_t tanh(const SplineKey &tanh_key, uint64_t blinded_input);

        void evaluate_maxpool_layer_inner_coeffs(const MaxPoolKey &k, uint64_t *x,
                                                 uint64_t *x_share, uint64_t rowsize, uint64_t *relu_sum,
                                                 uint64_t *relu_diff);

        void evaluate_maxpool_layer_outer_coeffs(const MaxPoolKey &k, uint64_t *x,
                                                 uint64_t *relu_sum, uint64_t *relu_diff, uint64_t rowsize,
                                                 uint64_t *output);

        uint64_t sigmoid(const SplineKey &sigmoid_key, uint64_t blinded_input);

        uint64_t eval_dpf_internal(const DPFKey &k, uint64_t x);

#ifdef FSS_ENABLE_FSS
        uint64_t eval_dpf_internal_mpc(const DPFKeyMPC& k, uint64_t x);

        uint64_t tanh_mpc(const SplineKeyMPC &tanh_key, uint64_t blinded_input);

        uint64_t relu_mpc(const ReLUKeyMPC &relu_key, uint64_t blinded_input);
#endif
    private:

        uint64_t eval_dif_internal(const DIFKey &k, uint64_t x);

        uint64_t eval_dif_spline_internal(const DIFKey &k, uint64_t x);

        uint64_t eval_max2_outer_coeffs_internal(const Max2Key &k, uint64_t x,
                                                 uint64_t y, uint64_t relu_sum, uint64_t relu_diff);

        uint64_t eval_max2_relu_diff_internal(const Max2Key &k, uint64_t x, uint64_t y, uint64_t y_share);

        uint64_t eval_max2_relu_sum_internal(const Max2Key &k, uint64_t x, uint64_t y);

#ifdef FSS_ENABLE_MPC
        uint64_t eval_dif_internal_mpc(const DIFKeyMPC& k, uint64_t x);
#endif

        std::shared_ptr<FSSContext> fss_context_;

        std::unique_ptr<ExpandingPRF> prf_;

        /*
         * Useful members for computations.
         */
        size_t num_bits_ = 0;

        size_t scaling_ = 0;

        SmallModulus plain_modulus_ = 0;

        SmallModulus plain_modulus_spline_ = 0;

        size_t server_id_ = 0;
    };

}
