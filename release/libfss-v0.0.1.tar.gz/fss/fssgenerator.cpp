
#include "fssgenerator.hpp"

using namespace seal::util;

namespace fss
{
    void FSSGenerator::relu(ReLUKey& key_s0, ReLUKey& key_s1)
    {
        // Init PRNG to sample from [0, plain_modulus_).
        std::random_device dev;
        std::mt19937_64 engine(dev());
        std::uniform_int_distribution<uint64_t> dist(0, plain_modulus_.value() - 1);

        // Sample random mask to use for blinding.
        key_s0.r = dist(engine);
        key_s1.r = dist(engine);
        auto rin = add_uint_uint_mod(key_s0.r, key_s1.r, plain_modulus_);

        std::vector<uint64_t> coeffs1 { 0, 1 };
        std::vector<uint64_t> coeffs2 {
                negate_uint_mod(multiply_uint_uint_mod(coeffs1[0], rin, plain_modulus_),
                        plain_modulus_),
                negate_uint_mod(multiply_uint_uint_mod(coeffs1[1], rin, plain_modulus_),
                        plain_modulus_) };

        std::vector<uint64_t> intervals { rin % plain_modulus_.value(),
                                          add_uint_uint_mod(rin, plain_mod_by_two_, plain_modulus_) };

        // Shift intervals if rin is negative.
        if (rin >= plain_mod_by_two_)
        {
            std::rotate(intervals.begin(), intervals.begin() + 1, intervals.end());
            std::rotate(coeffs1.begin(), coeffs1.begin() + 1, coeffs1.end());
            std::rotate(coeffs2.begin(), coeffs2.begin() + 1, coeffs2.end());
        }

        gen_dif_keys_internal(key_s0.f[0], key_s1.f[0],
                intervals[0],
                sub_uint_uint_mod(coeffs1[0], coeffs1[1], plain_modulus_));

        gen_dif_keys_internal(key_s0.f[1], key_s1.f[1],
                intervals[1],
                sub_uint_uint_mod(coeffs1[1], coeffs1[0], plain_modulus_));

        gen_dif_keys_internal(key_s0.f[2], key_s1.f[2],
                plain_modulus_.value() + 1,
                coeffs1[0] % plain_modulus_.value());

        gen_dif_keys_internal(key_s0.g[0], key_s1.g[0],
                intervals[0],
                sub_uint_uint_mod(coeffs2[0], coeffs2[1], plain_modulus_));

        gen_dif_keys_internal(key_s0.g[1], key_s1.g[1],
                intervals[1],
                sub_uint_uint_mod(coeffs2[1], coeffs2[0], plain_modulus_));

        gen_dif_keys_internal(key_s0.g[2], key_s1.g[2],
                plain_modulus_.value() + 1,
                coeffs2[0] % plain_modulus_.value());
    }

    void FSSGenerator::sigmoid(SplineKey& key_s0, SplineKey& key_s1)
    {
        // Init PRNG to sample from [0, plain_modulus_).
        std::random_device dev;
        std::mt19937_64 engine(dev());
        std::uniform_int_distribution<uint64_t> dist(0, plain_modulus_.value() - 1);

        // Sample random mask to use for blinding.
        key_s0.r = dist(engine);
        key_s1.r = dist(engine);
        key_s0.r = 0;
        key_s1.r = 0;
        auto rin = add_uint_uint_mod(key_s0.r, key_s1.r, plain_modulus_);

        std::vector<uint64_t> coeffs1 { 0, 1, 4, 8, 4, 1, 0 };
        std::vector<uint64_t> coeffs2_unscaled { 0u, 5u, 12u, 16u, 20u, 27u, 32u };
        std::vector<uint64_t> coeffs2 {
                sub_uint_uint_mod((coeffs2_unscaled[0] << (scaling_)), multiply_uint_uint_mod(coeffs1[0], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[1] << (scaling_)), multiply_uint_uint_mod(coeffs1[1], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[2] << (scaling_)), multiply_uint_uint_mod(coeffs1[2], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[3] << (scaling_)), multiply_uint_uint_mod(coeffs1[3], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[4] << (scaling_)), multiply_uint_uint_mod(coeffs1[4], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[5] << (scaling_)), multiply_uint_uint_mod(coeffs1[5], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[6] << (scaling_)), multiply_uint_uint_mod(coeffs1[6], rin,
                        plain_modulus_spline_), plain_modulus_spline_) };
        std::vector<uint64_t> intervals {
                sub_uint_uint_mod(rin, (40u << (scaling_ - 3)), plain_modulus_),
                sub_uint_uint_mod(rin, (19u << (scaling_ - 3)), plain_modulus_),
                sub_uint_uint_mod(rin, (8u << (scaling_ - 3)), plain_modulus_),
                add_uint_uint_mod(rin, (8u << (scaling_ - 3)), plain_modulus_),
                add_uint_uint_mod(rin, (19u << (scaling_ - 3)), plain_modulus_),
                add_uint_uint_mod(rin, (40u << (scaling_ - 3)), plain_modulus_),
                add_uint_uint_mod(rin, plain_mod_by_two_, plain_modulus_) };

        size_t rotate = 0;

        while (intervals[rotate] < intervals[rotate + 1] && rotate < 7)
        {
            rotate += 1;
        }
        if (rotate != 7)
        {
            std::rotate(intervals.begin(), intervals.begin() + rotate + 1, intervals.end());
            std::rotate(coeffs1.begin(), coeffs1.begin() + rotate + 1, coeffs1.end());
            std::rotate(coeffs2.begin(), coeffs2.begin() + rotate + 1, coeffs2.end());
        }

        gen_dif_spline_keys_internal(key_s0.f[0], key_s1.f[0], intervals[0],
                sub_uint_uint_mod(coeffs1[0], coeffs1[1], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[1], key_s1.f[1], intervals[1],
                sub_uint_uint_mod(coeffs1[1], coeffs1[2], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[2], key_s1.f[2], intervals[2],
                sub_uint_uint_mod(coeffs1[2], coeffs1[3], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[3], key_s1.f[3], intervals[3],
                sub_uint_uint_mod(coeffs1[3], coeffs1[4], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[4], key_s1.f[4], intervals[4],
                sub_uint_uint_mod(coeffs1[4], coeffs1[5], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[5], key_s1.f[5], intervals[5],
                sub_uint_uint_mod(coeffs1[5], coeffs1[6], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[6], key_s1.f[6], intervals[6],
                sub_uint_uint_mod(coeffs1[6], coeffs1[0], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[7], key_s1.f[7], plain_modulus_.value(), coeffs1[0]);

        gen_dif_spline_keys_internal(key_s0.g[0], key_s1.g[0], intervals[0],
                sub_uint_uint_mod(coeffs2[0], coeffs2[1], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[1], key_s1.g[1], intervals[1],
                sub_uint_uint_mod(coeffs2[1], coeffs2[2], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[2], key_s1.g[2], intervals[2],
                sub_uint_uint_mod(coeffs2[2], coeffs2[3], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[3], key_s1.g[3], intervals[3],
                sub_uint_uint_mod(coeffs2[3], coeffs2[4], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[4], key_s1.g[4], intervals[4],
                sub_uint_uint_mod(coeffs2[4], coeffs2[5], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[5], key_s1.g[5], intervals[5],
                sub_uint_uint_mod(coeffs2[5], coeffs2[6], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[6], key_s1.g[6], intervals[6],
                sub_uint_uint_mod(coeffs2[6], coeffs2[0], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[7], key_s1.g[7], plain_modulus_.value(), coeffs2[0]);
    }

    void FSSGenerator::tanh(SplineKey& key_s0, SplineKey& key_s1)
    {
        // Init PRNG to sample from [0, plain_modulus_).
        std::random_device dev;
        std::mt19937_64 engine(dev());
        std::uniform_int_distribution<uint64_t> dist(0, plain_modulus_.value() - 1);

        // Sample random mask to use for blinding.
        key_s0.r = dist(engine);
        key_s1.r = dist(engine);
        key_s0.r = 0;
        key_s1.r = 0;
        auto rin = add_uint_uint_mod(key_s0.r, key_s1.r, plain_modulus_);

        std::vector<uint64_t> coeffs1 { 0, 4, 8, 32, 8, 4, 0 };
        std::vector<uint64_t> coeffs2_unscaled { 32u, 22u, 8u, 0u, 8u, 22u, 32u };
        std::vector<uint64_t> coeffs2 {
                sub_uint_uint_mod((coeffs2_unscaled[0] << (scaling_)), multiply_uint_uint_mod(coeffs1[0], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[1] << (scaling_)), multiply_uint_uint_mod(coeffs1[1], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[2] << (scaling_)), multiply_uint_uint_mod(coeffs1[2], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[3] << (scaling_)), multiply_uint_uint_mod(coeffs1[3], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[4] << (scaling_)), multiply_uint_uint_mod(coeffs1[4], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[5] << (scaling_)), multiply_uint_uint_mod(coeffs1[5], rin,
                        plain_modulus_spline_), plain_modulus_spline_),
                sub_uint_uint_mod((coeffs2_unscaled[6] << (scaling_)), multiply_uint_uint_mod(coeffs1[6], rin,
                        plain_modulus_spline_), plain_modulus_spline_) };
        std::vector<uint64_t> intervals {
                sub_uint_uint_mod(rin, (40u << (scaling_ - 4)), plain_modulus_),
                sub_uint_uint_mod(rin, (19u << (scaling_ - 4)), plain_modulus_),
                sub_uint_uint_mod(rin, (8u << (scaling_ - 4)), plain_modulus_),
                add_uint_uint_mod(rin, (8u << (scaling_ - 4)), plain_modulus_),
                add_uint_uint_mod(rin, (19u << (scaling_ - 4)), plain_modulus_),
                add_uint_uint_mod(rin, (40u << (scaling_ - 4)), plain_modulus_),
                add_uint_uint_mod(rin, plain_mod_by_two_, plain_modulus_) };

        size_t rotate = 0;

        while (intervals[rotate] < intervals[rotate + 1] && rotate < 7)
        {
            rotate += 1;
        }
        if (rotate != 7)
        {
            std::rotate(intervals.begin(), intervals.begin() + rotate + 1, intervals.end());
            std::rotate(coeffs1.begin(), coeffs1.begin() + rotate + 1, coeffs1.end());
            std::rotate(coeffs2.begin(), coeffs2.begin() + rotate + 1, coeffs2.end());
        }

        gen_dif_spline_keys_internal(key_s0.f[0], key_s1.f[0], intervals[0],
                sub_uint_uint_mod(coeffs1[0], coeffs1[1], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[1], key_s1.f[1], intervals[1],
                sub_uint_uint_mod(coeffs1[1], coeffs1[2], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[2], key_s1.f[2], intervals[2],
                sub_uint_uint_mod(coeffs1[2], coeffs1[3], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[3], key_s1.f[3], intervals[3],
                sub_uint_uint_mod(coeffs1[3], coeffs1[4], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[4], key_s1.f[4], intervals[4],
                sub_uint_uint_mod(coeffs1[4], coeffs1[5], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[5], key_s1.f[5], intervals[5],
                sub_uint_uint_mod(coeffs1[5], coeffs1[6], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[6], key_s1.f[6], intervals[6],
                sub_uint_uint_mod(coeffs1[6], coeffs1[0], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.f[7], key_s1.f[7], plain_modulus_.value(), coeffs1[0]);

        gen_dif_spline_keys_internal(key_s0.g[0], key_s1.g[0], intervals[0],
                sub_uint_uint_mod(coeffs2[0], coeffs2[1], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[1], key_s1.g[1], intervals[1],
                sub_uint_uint_mod(coeffs2[1], coeffs2[2], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[2], key_s1.g[2], intervals[2],
                sub_uint_uint_mod(coeffs2[2], coeffs2[3], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[3], key_s1.g[3], intervals[3],
                sub_uint_uint_mod(coeffs2[3], coeffs2[4], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[4], key_s1.g[4], intervals[4],
                sub_uint_uint_mod(coeffs2[4], coeffs2[5], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[5], key_s1.g[5], intervals[5],
                sub_uint_uint_mod(coeffs2[5], coeffs2[6], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[6], key_s1.g[6], intervals[6],
                sub_uint_uint_mod(coeffs2[6], coeffs2[0], plain_modulus_spline_));
        gen_dif_spline_keys_internal(key_s0.g[7], key_s1.g[7], plain_modulus_.value() - 1, coeffs2[0]);
    }

    void FSSGenerator::max_pool(size_t pool_size, MaxPoolKey& k0, MaxPoolKey& k1, uint64_t mask)
    {
        uint64_t num = pool_size;
        uint32_t progress = 0, random_progress = 0, r_index = 0;
        uint64_t r = 0;
        uint32_t random_size = 0;
        uint64_t rows = fast_floor_log2(pool_size);
        uint64_t row_sizes[rows + 1];

        k0.pool_size = pool_size;
        k1.pool_size = pool_size;

        while (rows != 0)
        {
            random_size += num;
            row_sizes[rows--] = num;
            num = num / 2 + num % 2;
        }
        row_sizes[0] = 1;

        k0.f.resize(pool_size - 1);
        k1.f.resize(pool_size - 1);

        auto random_array = new uint64_t[random_size];

        k0.r.resize(pool_size);
        k1.r.resize(pool_size);

        for (uint32_t i = 0; i < fast_floor_log2(pool_size); i++)
        {
            for (uint32_t j = 0; j < row_sizes[i + 1] / 2; j++)
            {
                if (progress == 0)
                {
                    r = mask;
                }
                else
                {
                    r = random_array[r_index];
                    r_index += 1;
                }
                gen_max2_keys_internal(k0.f[progress], k1.f[progress], r);
                random_array[random_progress] = add_uint_uint_mod(k0.f[progress].r1, k1.f[progress].r1,
                        plain_modulus_);
                random_array[random_progress + 1] = add_uint_uint_mod(k0.f[progress].r2,
                        k1.f[progress].r2, plain_modulus_);

                k0.r[2 * j] = k0.f[progress].r1;
                k0.r[2 * j + 1] = k0.f[progress].r2;
                k1.r[2 * j] = k1.f[progress].r1;
                k1.r[2 * j + 1] = k1.f[progress].r2;

                if (2 * j == row_sizes[i + 1] - 2)
                {
                    k0.r[k0.pool_size - 1] = k0.f[progress].r2;
                    k1.r[k1.pool_size - 1] = k1.f[progress].r2;
                }

                random_progress += 2;
                progress += 1;
            }
            if (row_sizes[i + 1] % 2 == 1)
            {
                random_array[random_progress] = random_array[r_index];
                random_progress += 1;
                r_index += 1;
            }
        }

        free(random_array);
    }

    void FSSGenerator::argmax(size_t pool_size, ArgmaxKey& k0, ArgmaxKey& k1)
    {
        // Init PRNG to sample from [0, plain_modulus_).
        std::random_device dev;
        std::mt19937_64 engine(dev());
        std::uniform_int_distribution<uint64_t> dist(0, plain_modulus_.value() - 1);

        // Sample random mask to use for blinding.
        uint64_t R = dist(engine);
        R = 0;
        max_pool(pool_size, k0.maxpool_key, k1.maxpool_key, R);
        k0.last_layer.resize(pool_size);
        k1.last_layer.resize(pool_size);

        for (size_t i = 0; i < pool_size; i++)
        {
            gen_dpf_key_internal(k0.last_layer[i], k1.last_layer[i], sub_uint_uint_mod(R, add_uint_uint_mod(k0
                    .maxpool_key.r[i], k1.maxpool_key.r[i], plain_modulus_), plain_modulus_), negate_uint_mod(i,
                    plain_modulus_));
        }
    }

    void FSSGenerator::gen_max2_keys_internal(Max2Key& k0, Max2Key& k1, uint64_t r)
    {
        // Init PRNG to sample from [0, plain_modulus).
        std::random_device dev;
        std::mt19937_64 engine(dev());
        std::uniform_int_distribution<uint64_t> dist(0, plain_modulus_.value() - 1);

        // Init random masks to use in keys.
        auto rin10 = dist(engine);
        auto rin11 = dist(engine);
        auto rin20 = dist(engine);
        auto rin21 = dist(engine);
        auto rin30 = dist(engine);
        auto rin31 = dist(engine);
        auto rin40 = dist(engine);
        auto rin41 = dist(engine);

        // Store random masks inside Max2Keys.
        k0.r1 = rin10;
        k1.r1 = rin11;
        k0.r2 = rin20;
        k1.r2 = rin21;

        auto rin1 = add_uint_uint_mod(rin10, rin11, plain_modulus_);
        auto rin2 = add_uint_uint_mod(rin20, rin21, plain_modulus_);
        auto rin3 = add_uint_uint_mod(rin30, rin31, plain_modulus_);
        auto rin4 = add_uint_uint_mod(rin40, rin41, plain_modulus_);
        auto f1rin = sub_uint_uint_mod(rin1, rin2, plain_modulus_);

        /*
         * Set interval functions.
         */
        std::vector<uint64_t> f1coeffs1 { 0, 1 };
        std::vector<uint64_t> f1coeffs2 {
                sub_uint_uint_mod(
                        sub_uint_uint_mod(rin4, rin2, plain_modulus_),
                        multiply_uint_uint_mod(f1coeffs1[0], f1rin, plain_modulus_),
                        plain_modulus_),
                sub_uint_uint_mod(
                        sub_uint_uint_mod(rin4, rin2, plain_modulus_),
                        multiply_uint_uint_mod(f1coeffs1[1], f1rin, plain_modulus_),
                        plain_modulus_)
        };
        std::vector<uint64_t> f1intervals { f1rin % plain_modulus_.value(),
                                            add_uint_uint_mod(f1rin, plain_mod_by_two_, plain_modulus_) };

        std::vector<uint64_t> f2coeffs1 { 0, 1 };
        std::vector<uint64_t> f2coeffs2 {
                sub_uint_uint_mod(rin3,
                        multiply_uint_uint_mod(f2coeffs1[0], rin1, plain_modulus_),
                        plain_modulus_),
                sub_uint_uint_mod(rin3,
                        multiply_uint_uint_mod(f2coeffs1[1], rin1, plain_modulus_),
                        plain_modulus_)
        };
        std::vector<uint64_t> f2intervals { rin1 % plain_modulus_.value(),
                                            add_uint_uint_mod(rin1, plain_mod_by_two_, plain_modulus_) };

        std::vector<uint64_t> f3coeffs1 { 0, 1 };
        std::vector<uint64_t> f3coeffs2 {
                negate_uint_mod(multiply_uint_uint_mod(f3coeffs1[0], rin2, plain_modulus_),
                        plain_modulus_),
                negate_uint_mod(multiply_uint_uint_mod(f3coeffs1[1], rin2, plain_modulus_),
                        plain_modulus_)
        };
        std::vector<uint64_t> f3intervals { rin2 % plain_modulus_.value(),
                                            add_uint_uint_mod(rin2, plain_mod_by_two_, plain_modulus_) };

        if (f1rin % plain_modulus_.value() >= plain_mod_by_two_)
        {
            std::rotate(f1intervals.begin(), f1intervals.begin() + 1, f1intervals.end());
            std::rotate(f1coeffs1.begin(), f1coeffs1.begin() + 1, f1coeffs1.end());
            std::rotate(f1coeffs2.begin(), f1coeffs2.begin() + 1, f1coeffs2.end());
        }
        if (rin1 % plain_modulus_.value() >= plain_mod_by_two_)
        {
            std::rotate(f2intervals.begin(), f2intervals.begin() + 1, f2intervals.end());
            std::rotate(f2coeffs1.begin(), f2coeffs1.begin() + 1, f2coeffs1.end());
            std::rotate(f2coeffs2.begin(), f2coeffs2.begin() + 1, f2coeffs2.end());
        }
        if (rin2 % plain_modulus_.value() >= plain_mod_by_two_)
        {
            std::rotate(f3intervals.begin(), f3intervals.begin() + 1, f3intervals.end());
            std::rotate(f3coeffs1.begin(), f3coeffs1.begin() + 1, f3coeffs1.end());
            std::rotate(f3coeffs2.begin(), f3coeffs2.begin() + 1, f3coeffs2.end());
        }

        gen_dif_keys_internal(k0.f1[0], k1.f1[0], f1intervals[0],
                sub_uint_uint_mod(f1coeffs1[0], f1coeffs1[1], plain_modulus_));
        gen_dif_keys_internal(k0.f1[1], k1.f1[1], f1intervals[1],
                sub_uint_uint_mod(f1coeffs1[1], f1coeffs1[0], plain_modulus_));
        gen_dif_keys_internal(k0.f1[2], k1.f1[2], plain_modulus_.value() + 1,
                f1coeffs1[0] % plain_modulus_.value());

        gen_dif_keys_internal(k0.g1[0], k1.g1[0], f1intervals[0],
                sub_uint_uint_mod(f1coeffs2[0], f1coeffs2[1], plain_modulus_));
        gen_dif_keys_internal(k0.g1[1], k1.g1[1], f1intervals[1],
                sub_uint_uint_mod(f1coeffs2[1], f1coeffs2[0], plain_modulus_));
        gen_dif_keys_internal(k0.g1[2], k1.g1[2], plain_modulus_.value() + 1,
                f1coeffs2[0] % plain_modulus_.value());

        gen_dif_keys_internal(k0.f2[0], k1.f2[0], f2intervals[0],
                sub_uint_uint_mod(f2coeffs1[0], f2coeffs1[1], plain_modulus_));
        gen_dif_keys_internal(k0.f2[1], k1.f2[1], f2intervals[1],
                sub_uint_uint_mod(f2coeffs1[1], f2coeffs1[0], plain_modulus_));
        gen_dif_keys_internal(k0.f2[2], k1.f2[2], plain_modulus_.value() + 1,
                f2coeffs1[0] % plain_modulus_.value());

        gen_dif_keys_internal(k0.g2[0], k1.g2[0], f2intervals[0],
                sub_uint_uint_mod(f2coeffs2[0], f2coeffs2[1], plain_modulus_));
        gen_dif_keys_internal(k0.g2[1], k1.g2[1], f2intervals[1],
                sub_uint_uint_mod(f2coeffs2[1], f2coeffs2[0], plain_modulus_));
        gen_dif_keys_internal(k0.g2[2], k1.g2[2], plain_modulus_.value() + 1,
                f2coeffs2[0] % plain_modulus_.value());

        gen_dif_keys_internal(k0.f3[0], k1.f3[0], f3intervals[0],
                sub_uint_uint_mod(f3coeffs1[0], f3coeffs1[1], plain_modulus_));
        gen_dif_keys_internal(k0.f3[1], k1.f3[1], f3intervals[1],
                sub_uint_uint_mod(f3coeffs1[1], f3coeffs1[0], plain_modulus_));
        gen_dif_keys_internal(k0.f3[2], k1.f3[2], plain_modulus_.value() + 1,
                f3coeffs1[0] % plain_modulus_.value());

        gen_dif_keys_internal(k0.g3[0], k1.g3[0], f3intervals[0],
                sub_uint_uint_mod(f3coeffs2[0], f3coeffs2[1], plain_modulus_));
        gen_dif_keys_internal(k0.g3[1], k1.g3[1], f3intervals[1],
                sub_uint_uint_mod(f3coeffs2[1], f3coeffs2[0], plain_modulus_));
        gen_dif_keys_internal(k0.g3[2], k1.g3[2], plain_modulus_.value() + 1,
                f3coeffs2[0] % plain_modulus_.value());

        gen_dpf_key_internal(k0.f[0], k1.f[0], rin3, negate_uint_mod(1, plain_modulus_));
        gen_dpf_key_internal(k0.f[1], k1.f[1], sub_uint_uint_mod(rin3,
                add_uint_uint_mod(rin2, rin1, plain_modulus_), plain_modulus_),
                negate_uint_mod(1, plain_modulus_));

        gen_dpf_key_internal(k0.f[2], k1.f[2], rin3, sub_uint_uint_mod(rin4, rin3, plain_modulus_));
        gen_dpf_key_internal(k0.f[3], k1.f[3], sub_uint_uint_mod(rin3,
                add_uint_uint_mod(rin2, rin1, plain_modulus_), plain_modulus_),
                sub_uint_uint_mod(rin4, rin3, plain_modulus_));

        k0.r = sub_uint_uint_mod(r, rin30, plain_modulus_);
        k1.r = negate_uint_mod(rin31, plain_modulus_);
    }

    void FSSGenerator::gen_dpf_key_internal(DPFKey& k0, DPFKey& k1, uint64_t a_i, uint64_t b_i)
    {
        // set bits in keys and allocate memory
        k0.cw.resize(num_bits_);
        k1.cw.resize(num_bits_);

        // Figure out first relevant bit
        // n represents the number of LSB to compare

        // create arrays size (AES_key_size*2 + 2)
        u_char s0[32];
        u_char s1[32];

        // Set initial seeds for PRF
        if (!RAND_bytes((u_char*) s0, 16))
        {
            throw std::runtime_error("Random bytes failed.");
        }
        if (!RAND_bytes((u_char*) s1, 16))
        {
            throw std::runtime_error("Random bytes failed.");
        }

        u_char t0;
        u_char t1;

        // Figure out initial ts
        // Make sure t0a and t1a are different
        t0 = 0;
        t1 = 1;

        memcpy(k0.s, s0, 16);
        memcpy(k1.s, s1, 16);

        // Pick right keys to put into cipher
        u_char key0[16];
        u_char key1[16];
        memcpy(key0, (u_char*) s0, 16);
        memcpy(key1, (u_char*) s1, 16);

//    unsigned char tbit0 = t0[a];
//    unsigned char tbit1 = t1[a];

        u_char cs[16];
        u_char ct[2];
        u_char tbit0[2];
        u_char tbit1[2];
        u_char out0[48];
        u_char out1[48];

        int a;
        for (uint32_t i = 0; i < num_bits_; i++)
        {
            prf_->generate(key0, 48, out0);
            prf_->generate(key1, 48, out1);
            // Reset a and na bits
            a = get_bit(a_i, (64 - num_bits_ + i + 1));

            memcpy(s0, out0, 32);
            memcpy(s1, out1, 32);
            tbit0[0] = out0[32] % 2;
            tbit0[1] = out0[33] % 2;
            tbit1[0] = out1[32] % 2;
            tbit1[1] = out1[33] % 2;

            for (uint32_t j = 0; j < 16; j++)
            {
                cs[j] = s0[j + 16 * (1 - a)] ^ s1[j + 16 * (1 - a)];
            }

            ct[0] = tbit0[0] ^ tbit1[0] ^ a ^ 1;
            ct[1] = tbit0[1] ^ tbit1[1] ^ a;
            memcpy(k0.cw[i].cs, cs, 16);
            k0.cw[i].ct[0] = ct[0];
            k0.cw[i].ct[1] = ct[1];
            memcpy(k1.cw[i].cs, cs, 16);
            k1.cw[i].ct[0] = ct[0];
            k1.cw[i].ct[1] = ct[1];
            if (t0 == 0)
            {
                for (uint32_t j = 0; j < 16; j++)
                {
                    key0[j] = s0[j + 16 * a];
                }
                t0 = tbit0[a];
            }
            else
            {
                for (uint32_t j = 0; j < 16; j++)
                {
                    key0[j] = s0[j + 16 * a] ^ cs[j];
                }
                t0 = tbit0[a] ^ ct[a];
            }
            if (t1 == 0)
            {
                for (uint32_t j = 0; j < 16; j++)
                {
                    key1[j] = s1[j + 16 * a];
                }
                t1 = tbit1[a];
            }
            else
            {
                for (uint32_t j = 0; j < 16; j++)
                {
                    key1[j] = s1[j + 16 * a] ^ cs[j];
                }
                t1 = tbit1[a] ^ ct[a];
            }
        }

        uint64_t cw_last, cw_last_temp0, cw_last_temp1;
        cw_last_temp0 = (uint64_t) key0[0] << 56u |
                        (uint64_t) key0[1] << 48u |
                        (uint64_t) key0[2] << 40u |
                        (uint64_t) key0[3] << 32u |
                        (uint64_t) key0[4] << 24u |
                        (uint64_t) key0[5] << 16u |
                        (uint64_t) key0[6] << 8u |
                        (uint64_t) key0[7];
        cw_last_temp1 = (uint64_t) key1[0] << 56u |
                        (uint64_t) key1[1] << 48u |
                        (uint64_t) key1[2] << 40u |
                        (uint64_t) key1[3] << 32u |
                        (uint64_t) key1[4] << 24u |
                        (uint64_t) key1[5] << 16u |
                        (uint64_t) key1[6] << 8u |
                        (uint64_t) key1[7];
        cw_last_temp0 = cw_last_temp0 % plain_modulus_.value();
        cw_last_temp1 = cw_last_temp1 % plain_modulus_.value();

        if (t1 == 0)
        {
            cw_last = add_uint_uint_mod(sub_uint_uint_mod(b_i, cw_last_temp0, plain_modulus_), cw_last_temp1,
                    plain_modulus_);
        }
        else
        {
            cw_last = sub_uint_uint_mod(cw_last_temp0, add_uint_uint_mod(b_i, cw_last_temp1, plain_modulus_),
                    plain_modulus_);
        }
        k0.cw_last = cw_last;
        k1.cw_last = cw_last;
    }

    void FSSGenerator::gen_dif_keys_internal(DIFKey& k0, DIFKey& k1, uint64_t a_i, uint64_t b_i)
    {
        // Set up num_bits and allocate memory
        k0.cw.resize(num_bits_);
        k1.cw.resize(num_bits_);

        // create arrays size (AES_key_size*2 + 2).
        u_char s0[16];
        u_char s1[16];

        // Set initial seeds for PRF.
        if (!RAND_bytes((u_char*) (s0), 16))
        {
            throw std::runtime_error("Random bytes failed.");
        }
        if (!RAND_bytes((u_char*) (s1), 16))
        {
            throw std::runtime_error("Random bytes failed.");
        }

        u_char t0;
        u_char t1;
        u_char temp;
        if (!RAND_bytes((u_char*) (&temp), 1))
        {
            throw std::runtime_error("Random bytes failed.");
        }

        // Figure out initial ts
        // Make sure t0a and t1a are different
        t0 = 0;
        t1 = 1;

        memcpy(k0.s, s0, 16);
        memcpy(k1.s, s1, 16);
        k0.t = t0;
        k1.t = t1;


        u_char out0[64];
        u_char out1[64];

        uint64_t v0[2];
        uint64_t v1[2];

        u_char cs[16];
        u_char ct0;
        u_char ct1;

        uint64_t cv0;
        uint64_t cv1;

        uint64_t a;
        uint64_t na;

        for (size_t i = 0; i < num_bits_; i++)
        {
            prf_->generate(s0, 64, out0);
            prf_->generate(s1, 64, out1);

            out0[32] = out0[32] % 2;
            out0[33] = out0[33] % 2;
            out1[32] = out1[32] % 2;
            out1[33] = out1[33] % 2;

            v0[0] = byte_array_to_integer((u_char*) (out0 + 40)) % plain_modulus_.value();
            v0[1] = byte_array_to_integer((u_char*) (out0 + 48)) % plain_modulus_.value();
            v1[0] = byte_array_to_integer((u_char*) (out1 + 40)) % plain_modulus_.value();
            v1[1] = byte_array_to_integer((u_char*) (out1 + 48)) % plain_modulus_.value();

            // Reset a and na bits
            a = get_bit(a_i, (64 - num_bits_ + i + 1));
            na = a ^ 1u;

            // Redefine aStart and naStart based on new a's
            uint64_t naStart = 16 * na;

            // cs
            for (size_t j = 0; j < 16; j++)
            {
                cs[j] = out0[naStart + j] ^ out1[naStart + j];
            }

            // ct0
            ct0 = out0[32] ^ out1[32] ^ a ^ 1;
            ct1 = out0[33] ^ out1[33] ^ a;

            // cv
            cv0 = sub_uint_uint_mod(
                    sub_uint_uint_mod(v0[0], v1[0], plain_modulus_),
                    multiply_uint_uint_mod(b_i, a, plain_modulus_),
                    plain_modulus_);

            if (t0)
            {
                cv0 = negate_uint_mod(cv0, plain_modulus_);
            }

            cv1 = sub_uint_uint_mod(v0[1], v1[1], plain_modulus_);
            if (t0)
            {
                cv1 = negate_uint_mod(cv1, plain_modulus_);
            }

            // Copy appropriate values into key
            memcpy(k0.cw[i].cs, cs, 16);
            k0.cw[i].ct[0] = ct0;
            k0.cw[i].ct[1] = ct1;

            k0.cw[i].cv[0] = cv0;
            k0.cw[i].cv[1] = cv1;

            memcpy(k1.cw[i].cs, cs, 16);
            k1.cw[i].ct[0] = ct0;
            k1.cw[i].ct[1] = ct1;

            k1.cw[i].cv[0] = cv0;
            k1.cw[i].cv[1] = cv1;

            u_char* rs;
            if (a)
            {
                // update s0
                rs = (u_char*) (out0 + 16);
                for (size_t j = 0; j < 16; j++)
                {
                    s0[j] = rs[j] ^ (cs[j] * t0);
                }
                rs = (u_char*) (out1 + 16);
                for (size_t j = 0; j < 16; j++)
                {
                    s1[j] = rs[j] ^ (cs[j] * t1);
                }
                // update  t0 and t1
                t0 = out0[33] ^ (ct1 * t0);
                t1 = out1[33] ^ (ct1 * t1);
            }
            else
            {
                rs = (u_char*) (out0);
                for (size_t j = 0; j < 16; j++)
                {
                    s0[j] = rs[j] ^ (cs[j] * t0);
                }
                rs = (u_char*) (out1);
                for (size_t j = 0; j < 16; j++)
                {
                    s1[j] = rs[j] ^ (cs[j] * t1);
                }
                t0 = out0[32] ^ (ct0 * t0);
                t1 = out1[32] ^ (ct0 * t1);
            }
        }
    }

    void FSSGenerator::gen_dif_spline_keys_internal(DIFKey& k0, DIFKey& k1, uint64_t a_i, uint64_t b_i)
    {
        // Set up num_bits and allocate memory
        k0.cw.resize(num_bits_);
        k1.cw.resize(num_bits_);

        // create arrays size (AES_key_size*2 + 2).
        u_char s0[16];
        u_char s1[16];

        // Set initial seeds for PRF.
        if (!RAND_bytes((u_char*) (s0), 16))
        {
            throw std::runtime_error("Random bytes failed.");
        }
        if (!RAND_bytes((u_char*) (s1), 16))
        {
            throw std::runtime_error("Random bytes failed.");
        }

        u_char t0;
        u_char t1;
        u_char temp;
        if (!RAND_bytes((u_char*) (&temp), 1))
        {
            throw std::runtime_error("Random bytes failed.");
        }

        // Figure out initial ts
        // Make sure t0a and t1a are different
        t0 = 0;
        t1 = 1;

        memcpy(k0.s, s0, 16);
        memcpy(k1.s, s1, 16);
        k0.t = t0;
        k1.t = t1;


        u_char out0[64];
        u_char out1[64];

        uint64_t v0[2];
        uint64_t v1[2];

        u_char cs[16];
        u_char ct0;
        u_char ct1;

        uint64_t cv0;
        uint64_t cv1;

        uint64_t a;
        uint64_t na;

        for (size_t i = 0; i < num_bits_; i++)
        {
            prf_->generate(s0, 64, out0);
            prf_->generate(s1, 64, out1);

            out0[32] = out0[32] % 2;
            out0[33] = out0[33] % 2;
            out1[32] = out1[32] % 2;
            out1[33] = out1[33] % 2;

            v0[0] = byte_array_to_integer((u_char*) (out0 + 40)) % plain_modulus_spline_.value();
            v0[1] = byte_array_to_integer((u_char*) (out0 + 48)) % plain_modulus_spline_.value();
            v1[0] = byte_array_to_integer((u_char*) (out1 + 40)) % plain_modulus_spline_.value();
            v1[1] = byte_array_to_integer((u_char*) (out1 + 48)) % plain_modulus_spline_.value();

            // Reset a and na bits
            a = get_bit(a_i, (64 - num_bits_ + i + 1));
            na = a ^ 1u;

            // Redefine aStart and naStart based on new a's
            uint64_t naStart = 16 * na;

            // cs
            for (size_t j = 0; j < 16; j++)
            {
                cs[j] = out0[naStart + j] ^ out1[naStart + j];
            }

            // ct0
            ct0 = out0[32] ^ out1[32] ^ a ^ 1;
            ct1 = out0[33] ^ out1[33] ^ a;

            // cv
            cv0 = sub_uint_uint_mod(
                    sub_uint_uint_mod(v0[0], v1[0], plain_modulus_spline_),
                    multiply_uint_uint_mod(b_i, a, plain_modulus_spline_),
                    plain_modulus_spline_);

            if (t0)
            {
                cv0 = negate_uint_mod(cv0, plain_modulus_spline_);
            }

            cv1 = sub_uint_uint_mod(v0[1], v1[1], plain_modulus_spline_);
            if (t0)
            {
                cv1 = negate_uint_mod(cv1, plain_modulus_spline_);
            }

            // Copy appropriate values into key
            memcpy(k0.cw[i].cs, cs, 16);
            k0.cw[i].ct[0] = ct0;
            k0.cw[i].ct[1] = ct1;

            k0.cw[i].cv[0] = cv0;
            k0.cw[i].cv[1] = cv1;

            memcpy(k1.cw[i].cs, cs, 16);
            k1.cw[i].ct[0] = ct0;
            k1.cw[i].ct[1] = ct1;

            k1.cw[i].cv[0] = cv0;
            k1.cw[i].cv[1] = cv1;

            u_char* rs;
            if (a)
            {
                // update s0
                rs = (u_char*) (out0 + 16);
                for (size_t j = 0; j < 16; j++)
                {
                    s0[j] = rs[j] ^ (cs[j] * t0);
                }
                rs = (u_char*) (out1 + 16);
                for (size_t j = 0; j < 16; j++)
                {
                    s1[j] = rs[j] ^ (cs[j] * t1);
                }
                // update  t0 and t1
                t0 = out0[33] ^ (ct1 * t0);
                t1 = out1[33] ^ (ct1 * t1);
            }
            else
            {
                rs = (u_char*) (out0);
                for (size_t j = 0; j < 16; j++)
                {
                    s0[j] = rs[j] ^ (cs[j] * t0);
                }
                rs = (u_char*) (out1);
                for (size_t j = 0; j < 16; j++)
                {
                    s1[j] = rs[j] ^ (cs[j] * t1);
                }
                t0 = out0[32] ^ (ct0 * t0);
                t1 = out1[32] ^ (ct0 * t1);
            }
        }
    }

#ifdef FSS_ENABLE_MPC
    void FSSGenerator::relu_mpc(ReLUKeyMPC &key_s0, ReLUKeyMPC &key_s1)
        {
            // Init PRNG to sample from [0, plain_modulus_).
            std::random_device dev;
            std::mt19937_64 engine(dev());
            std::uniform_int_distribution<uint64_t> dist(0, plain_modulus_.value() - 1);

            // Sample random mask to use for blinding.
            key_s0.r = dist(engine);
            key_s1.r = dist(engine);
            auto rin = add_uint_uint_mod(key_s0.r, key_s1.r, plain_modulus_);

            std::vector<uint64_t> coeffs1 { 0, 1 };
            std::vector<uint64_t> coeffs2 {
                    negate_uint_mod(multiply_uint_uint_mod(coeffs1[0], rin, plain_modulus_),
                            plain_modulus_),
                    negate_uint_mod(multiply_uint_uint_mod(coeffs1[1], rin, plain_modulus_),
                            plain_modulus_) };

            std::vector<uint64_t> intervals { rin % plain_modulus_.value(),
                                              add_uint_uint_mod(rin, plain_mod_by_two_, plain_modulus_) };

            // Shift intervals if rin is negative.
            if (rin >= plain_mod_by_two_)
            {
                std::rotate(intervals.begin(), intervals.begin() + 1, intervals.end());
                std::rotate(coeffs1.begin(), coeffs1.begin() + 1, coeffs1.end());
                std::rotate(coeffs2.begin(), coeffs2.begin() + 1, coeffs2.end());
            }

            gen_dif_keys_internal_mpc(key_s0.f[0], key_s1.f[0],
                    intervals[0],
                    sub_uint_uint_mod(coeffs1[0], coeffs1[1], plain_modulus_));

            gen_dif_keys_internal_mpc(key_s0.f[1], key_s1.f[1],
                    intervals[1],
                    sub_uint_uint_mod(coeffs1[1], coeffs1[0], plain_modulus_));

            gen_dif_keys_internal_mpc(key_s0.f[2], key_s1.f[2],
                    plain_modulus_.value() + 1,
                    coeffs1[0] % plain_modulus_.value());

            gen_dif_keys_internal_mpc(key_s0.g[0], key_s1.g[0],
                    intervals[0],
                    sub_uint_uint_mod(coeffs2[0], coeffs2[1], plain_modulus_));

            gen_dif_keys_internal_mpc(key_s0.g[1], key_s1.g[1],
                    intervals[1],
                    sub_uint_uint_mod(coeffs2[1], coeffs2[0], plain_modulus_));

            gen_dif_keys_internal_mpc(key_s0.g[2], key_s1.g[2],
                    plain_modulus_.value() + 1,
                    coeffs2[0] % plain_modulus_.value());
        }
        void FSSGenerator::tanh_mpc(SplineKeyMPC &key_s0, SplineKeyMPC &key_s1)
        {
            // Init PRNG to sample from [0, plain_modulus_).
            std::random_device dev;
            std::mt19937_64 engine(dev());
            std::uniform_int_distribution<uint64_t> dist(0, plain_modulus_.value() - 1);

            // Sample random mask to use for blinding.
            key_s0.r = dist(engine);
            key_s1.r = dist(engine);
            key_s0.r = 0;
            key_s1.r = 0;
            auto rin = add_uint_uint_mod(key_s0.r, key_s1.r, plain_modulus_);

            std::vector<uint64_t> coeffs1 { 0, 4, 8, 32, 8, 4, 0 };
            std::vector<uint64_t> coeffs2_unscaled { 32u, 22u, 8u, 0u, 8u, 22u, 32u };
            std::vector<uint64_t> coeffs2 {
                    sub_uint_uint_mod((coeffs2_unscaled[0] << (scaling_)), multiply_uint_uint_mod(coeffs1[0], rin,
                            plain_modulus_spline_), plain_modulus_spline_),
                    sub_uint_uint_mod((coeffs2_unscaled[1] << (scaling_)), multiply_uint_uint_mod(coeffs1[1], rin,
                            plain_modulus_spline_), plain_modulus_spline_),
                    sub_uint_uint_mod((coeffs2_unscaled[2] << (scaling_)), multiply_uint_uint_mod(coeffs1[2], rin,
                            plain_modulus_spline_), plain_modulus_spline_),
                    sub_uint_uint_mod((coeffs2_unscaled[3] << (scaling_)), multiply_uint_uint_mod(coeffs1[3], rin,
                            plain_modulus_spline_), plain_modulus_spline_),
                    sub_uint_uint_mod((coeffs2_unscaled[4] << (scaling_)), multiply_uint_uint_mod(coeffs1[4], rin,
                            plain_modulus_spline_), plain_modulus_spline_),
                    sub_uint_uint_mod((coeffs2_unscaled[5] << (scaling_)), multiply_uint_uint_mod(coeffs1[5], rin,
                            plain_modulus_spline_), plain_modulus_spline_),
                    sub_uint_uint_mod((coeffs2_unscaled[6] << (scaling_)), multiply_uint_uint_mod(coeffs1[6], rin,
                            plain_modulus_spline_), plain_modulus_spline_) };
            std::vector<uint64_t> intervals {
                    sub_uint_uint_mod(rin, (40u << (scaling_ - 4)), plain_modulus_),
                    sub_uint_uint_mod(rin, (19u << (scaling_ - 4)), plain_modulus_),
                    sub_uint_uint_mod(rin, (8u << (scaling_ - 4)), plain_modulus_),
                    add_uint_uint_mod(rin, (8u << (scaling_ - 4)), plain_modulus_),
                    add_uint_uint_mod(rin, (19u << (scaling_ - 4)), plain_modulus_),
                    add_uint_uint_mod(rin, (40u << (scaling_ - 4)), plain_modulus_),
                    add_uint_uint_mod(rin, plain_mod_by_two_, plain_modulus_) };

            size_t rotate = 0;

            while (intervals[rotate] < intervals[rotate + 1] && rotate < 7)
            {
                rotate += 1;
            }
            if (rotate != 7)
            {
                std::rotate(intervals.begin(), intervals.begin() + rotate + 1, intervals.end());
                std::rotate(coeffs1.begin(), coeffs1.begin() + rotate + 1, coeffs1.end());
                std::rotate(coeffs2.begin(), coeffs2.begin() + rotate + 1, coeffs2.end());
            }

            gen_dif_keys_internal_mpc(key_s0.f[0], key_s1.f[0], intervals[0],
                    sub_uint_uint_mod(coeffs1[0], coeffs1[1], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.f[1], key_s1.f[1], intervals[1],
                    sub_uint_uint_mod(coeffs1[1], coeffs1[2], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.f[2], key_s1.f[2], intervals[2],
                    sub_uint_uint_mod(coeffs1[2], coeffs1[3], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.f[3], key_s1.f[3], intervals[3],
                    sub_uint_uint_mod(coeffs1[3], coeffs1[4], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.f[4], key_s1.f[4], intervals[4],
                    sub_uint_uint_mod(coeffs1[4], coeffs1[5], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.f[5], key_s1.f[5], intervals[5],
                    sub_uint_uint_mod(coeffs1[5], coeffs1[6], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.f[6], key_s1.f[6], intervals[6],
                    sub_uint_uint_mod(coeffs1[6], coeffs1[0], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.f[7], key_s1.f[7], plain_modulus_.value(), coeffs1[0]);

            gen_dif_keys_internal_mpc(key_s0.g[0], key_s1.g[0], intervals[0],
                    sub_uint_uint_mod(coeffs2[0], coeffs2[1], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.g[1], key_s1.g[1], intervals[1],
                    sub_uint_uint_mod(coeffs2[1], coeffs2[2], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.g[2], key_s1.g[2], intervals[2],
                    sub_uint_uint_mod(coeffs2[2], coeffs2[3], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.g[3], key_s1.g[3], intervals[3],
                    sub_uint_uint_mod(coeffs2[3], coeffs2[4], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.g[4], key_s1.g[4], intervals[4],
                    sub_uint_uint_mod(coeffs2[4], coeffs2[5], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.g[5], key_s1.g[5], intervals[5],
                    sub_uint_uint_mod(coeffs2[5], coeffs2[6], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.g[6], key_s1.g[6], intervals[6],
                    sub_uint_uint_mod(coeffs2[6], coeffs2[0], plain_modulus_spline_));
            gen_dif_keys_internal_mpc(key_s0.g[7], key_s1.g[7], plain_modulus_.value() - 1, coeffs2[0]);
        }

        void FSSGenerator::gen_dpf_key_internal_mpc(DPFKeyMPC& k0, DPFKeyMPC& k1, uint64_t a_i, uint64_t b_i)
    {
        // set bits in keys and allocate memory
        k0.cw.resize(num_bits_);
        k1.cw.resize(num_bits_);

        // Figure out first relevant bit
        // n represents the number of LSB to compare

        // create arrays size (AES_key_size*2 + 2)
        u_char s0[96];
        u_char s1[96];

        // Set initial seeds for PRF
        if (!RAND_bytes((u_char*) s0, 96))
        {
            throw std::runtime_error("Random bytes failed.");
        }
        if (!RAND_bytes((u_char*) s1, 96))
        {
            throw std::runtime_error("Random bytes failed.");
        }

        u_char t0;
        u_char t1;

        // Figure out initial ts
        // Make sure t0a and t1a are different
        t0 = 0;
        t1 = 1;

        memcpy(k0.s, s0, 48);
        memcpy(k1.s, s1, 48);

        // Pick right keys to put into cipher
        u_char key0[48];
        u_char key1[48];
        memcpy(key0, (u_char*) s0, 48);
        memcpy(key1, (u_char*) s1, 48);

//    unsigned char tbit0 = t0[a];
//    unsigned char tbit1 = t1[a];

        u_char cs[48];
        u_char ct[2];
        u_char tbit0[2];
        u_char tbit1[2];
        u_char out0[112];
        u_char out1[112];
        u_char out00[112];
        u_char out10[112];
        u_char out01[112];
        u_char out11[112];
        u_char out02[112];
        u_char out12[112];

        int a;
        for (uint32_t i = 0; i < num_bits_; i++)
        {
            prf_->generate(key0, 48, out00);
            prf_->generate(key1, 48, out10);
            prf_->generate(key0 + 16, 48, out01);
            prf_->generate(key1 + 16, 48, out11);
            prf_->generate(key0 + 32, 48, out02);
            prf_->generate(key1 + 32, 48, out12);

            for (size_t prf_index = 0; prf_index < 112; prf_index++)
            {
                out0[prf_index] = out00[prf_index] ^ out01[prf_index] ^ out02[prf_index];
                out1[prf_index] = out10[prf_index] ^ out11[prf_index] ^ out12[prf_index];
            }


            // Reset a and na bits
            a = get_bit(a_i, (64 - num_bits_ + i + 1));

            memcpy(s0, out0, 96);
            memcpy(s1, out1, 96);
            tbit0[0] = out0[96] % 2;
            tbit0[1] = out0[97] % 2;
            tbit1[0] = out1[96] % 2;
            tbit1[1] = out1[97] % 2;

            for (uint32_t j = 0; j < 48; j++)
            {
                cs[j] = s0[j + 48 * (1 - a)] ^ s1[j + 48 * (1 - a)];
            }

            ct[0] = tbit0[0] ^ tbit1[0] ^ a ^ 1;
            ct[1] = tbit0[1] ^ tbit1[1] ^ a;
            memcpy(k0.cw[i].cs, cs, 48);
            k0.cw[i].ct[0] = ct[0];
            k0.cw[i].ct[1] = ct[1];
            memcpy(k1.cw[i].cs, cs, 48);
            k1.cw[i].ct[0] = ct[0];
            k1.cw[i].ct[1] = ct[1];
            if (t0 == 0)
            {
                for (uint32_t j = 0; j < 48; j++)
                {
                    key0[j] = s0[j + 48 * a];
                }
                t0 = tbit0[a];
            }
            else
            {
                for (uint32_t j = 0; j < 48; j++)
                {
                    key0[j] = s0[j + 48 * a] ^ cs[j];
                }
                t0 = tbit0[a] ^ ct[a];
            }
            if (t1 == 0)
            {
                for (uint32_t j = 0; j < 48; j++)
                {
                    key1[j] = s1[j + 48 * a];
                }
                t1 = tbit1[a];
            }
            else
            {
                for (uint32_t j = 0; j < 48; j++)
                {
                    key1[j] = s1[j + 48 * a] ^ cs[j];
                }
                t1 = tbit1[a] ^ ct[a];
            }
        }

        uint64_t cw_last, cw_last_temp0, cw_last_temp1, cw_last_temp00, cw_last_temp10, cw_last_temp01,
                cw_last_temp11, cw_last_temp02, cw_last_temp12;
        cw_last_temp00 = (uint64_t) key0[0] << 56u |
                         (uint64_t) key0[1] << 48u |
                         (uint64_t) key0[2] << 40u |
                         (uint64_t) key0[3] << 32u |
                         (uint64_t) key0[4] << 24u |
                         (uint64_t) key0[5] << 16u |
                         (uint64_t) key0[6] << 8u |
                         (uint64_t) key0[7];
        cw_last_temp10 = (uint64_t) key1[0] << 56u |
                         (uint64_t) key1[1] << 48u |
                         (uint64_t) key1[2] << 40u |
                         (uint64_t) key1[3] << 32u |
                         (uint64_t) key1[4] << 24u |
                         (uint64_t) key1[5] << 16u |
                         (uint64_t) key1[6] << 8u |
                         (uint64_t) key1[7];
        cw_last_temp01 = (uint64_t) key0[0 + 16] << 56u |
                         (uint64_t) key0[1 + 16] << 48u |
                         (uint64_t) key0[2 + 16] << 40u |
                         (uint64_t) key0[3 + 16] << 32u |
                         (uint64_t) key0[4 + 16] << 24u |
                         (uint64_t) key0[5 + 16] << 16u |
                         (uint64_t) key0[6 + 16] << 8u |
                         (uint64_t) key0[7 + 16];
        cw_last_temp11 = (uint64_t) key1[0 + 16] << 56u |
                         (uint64_t) key1[1 + 16] << 48u |
                         (uint64_t) key1[2 + 16] << 40u |
                         (uint64_t) key1[3 + 16] << 32u |
                         (uint64_t) key1[4 + 16] << 24u |
                         (uint64_t) key1[5 + 16] << 16u |
                         (uint64_t) key1[6 + 16] << 8u |
                         (uint64_t) key1[7 + 16];
        cw_last_temp02 = (uint64_t) key0[0 + 32] << 56u |
                         (uint64_t) key0[1 + 32] << 48u |
                         (uint64_t) key0[2 + 32] << 40u |
                         (uint64_t) key0[3 + 32] << 32u |
                         (uint64_t) key0[4 + 32] << 24u |
                         (uint64_t) key0[5 + 32] << 16u |
                         (uint64_t) key0[6 + 32] << 8u |
                         (uint64_t) key0[7 + 32];
        cw_last_temp12 = (uint64_t) key1[0 + 32] << 56u |
                         (uint64_t) key1[1 + 32] << 48u |
                         (uint64_t) key1[2 + 32] << 40u |
                         (uint64_t) key1[3 + 32] << 32u |
                         (uint64_t) key1[4 + 32] << 24u |
                         (uint64_t) key1[5 + 32] << 16u |
                         (uint64_t) key1[6 + 32] << 8u |
                         (uint64_t) key1[7 + 32];
        cw_last_temp00 = cw_last_temp00 % plain_modulus_.value();
        cw_last_temp10 = cw_last_temp10 % plain_modulus_.value();
        cw_last_temp01 = cw_last_temp01 % plain_modulus_.value();
        cw_last_temp11 = cw_last_temp11 % plain_modulus_.value();
        cw_last_temp02 = cw_last_temp02 % plain_modulus_.value();
        cw_last_temp12 = cw_last_temp12 % plain_modulus_.value();

        cw_last_temp0 = add_uint_uint_mod(add_uint_uint_mod(cw_last_temp00, cw_last_temp01, plain_modulus_),
                cw_last_temp02, plain_modulus_);
        cw_last_temp1 = add_uint_uint_mod(add_uint_uint_mod(cw_last_temp10, cw_last_temp11, plain_modulus_),
                cw_last_temp12, plain_modulus_);

        if (t1 == 0)
        {
            cw_last = add_uint_uint_mod(sub_uint_uint_mod(b_i, cw_last_temp0, plain_modulus_), cw_last_temp1,
                    plain_modulus_);
        }
        else
        {
            cw_last = sub_uint_uint_mod(cw_last_temp0, add_uint_uint_mod(b_i, cw_last_temp1, plain_modulus_),
                    plain_modulus_);
        }
        k0.cw_last = cw_last;
        k1.cw_last = cw_last;
    }

    void FSSGenerator::gen_dif_keys_internal_mpc(DIFKeyMPC& k0, DIFKeyMPC& k1, uint64_t a_i, uint64_t b_i)
    {
        // Set up num_bits and allocate memory
        k0.cw.resize(num_bits_);
        k1.cw.resize(num_bits_);

        // create arrays size (AES_key_size*2 + 2).
        u_char s0[48];
        u_char s1[48];

        // Set initial seeds for PRF.
        if (!RAND_bytes((u_char*) (s0), 48))
        {
            throw std::runtime_error("Random bytes failed.");
        }
        if (!RAND_bytes((u_char*) (s1), 48))
        {
            throw std::runtime_error("Random bytes failed.");
        }

        u_char t0;
        u_char t1;
        u_char temp;
        if (!RAND_bytes((u_char*) (&temp), 1))
        {
            throw std::runtime_error("Random bytes failed.");
        }

        // Figure out initial ts
        // Make sure t0a and t1a are different
        t0 = 0;
        t1 = 1;

        memcpy(k0.s, s0, 48);
        memcpy(k1.s, s1, 48);
        k0.t = t0;
        k1.t = t1;


        u_char out0[128];
        u_char out1[128];


        u_char out00[128];
        u_char out10[128];


        u_char out01[128];
        u_char out11[128];


        u_char out02[128];
        u_char out12[128];

        uint64_t v0[2];
        uint64_t v1[2];

        u_char cs[48];
        u_char ct0;
        u_char ct1;

        uint64_t cv0;
        uint64_t cv1;

        uint64_t a;
        uint64_t na;

        for (size_t i = 0; i < num_bits_; i++)
        {
            prf_->generate(s0, 128, out00);
            prf_->generate(s1, 128, out10);
            prf_->generate(s0 + 16, 128, out01);
            prf_->generate(s1 + 16, 128, out11);
            prf_->generate(s0 + 32, 128, out02);
            prf_->generate(s1 + 32, 128, out12);

            for (size_t prf_index = 0; prf_index < 112; prf_index++)
            {
                out0[prf_index] = out00[prf_index] ^ out01[prf_index] ^ out02[prf_index];
                out1[prf_index] = out10[prf_index] ^ out11[prf_index] ^ out12[prf_index];
            }

            out0[96] = out0[96] % 2;
            out0[97] = out0[97] % 2;
            out1[96] = out1[96] % 2;
            out1[97] = out1[97] % 2;

            v0[0] = add_uint_uint_mod(byte_array_to_integer((u_char*) (out00 + 40)) % plain_modulus_.value(),
                    byte_array_to_integer((u_char*) (out01 + 40)) % plain_modulus_.value(),
                    plain_modulus_);
            v0[0] = add_uint_uint_mod(v0[0], byte_array_to_integer((u_char*) (out02 + 40)) % plain_modulus_.value(),
                    plain_modulus_);

            v0[1] = add_uint_uint_mod(byte_array_to_integer((u_char*) (out00 + 48)) % plain_modulus_.value(),
                    byte_array_to_integer((u_char*) (out01 + 48)) % plain_modulus_.value(),
                    plain_modulus_);
            v0[1] = add_uint_uint_mod(v0[1], byte_array_to_integer((u_char*) (out02 + 48)) % plain_modulus_.value(),
                    plain_modulus_);

            v1[0] = add_uint_uint_mod(byte_array_to_integer((u_char*) (out10 + 40)) % plain_modulus_.value(),
                    byte_array_to_integer((u_char*) (out11 + 40)) % plain_modulus_.value(),
                    plain_modulus_);
            v1[0] = add_uint_uint_mod(v1[0], byte_array_to_integer((u_char*) (out12 + 40)) % plain_modulus_.value(),
                    plain_modulus_);

            v1[1] = add_uint_uint_mod(byte_array_to_integer((u_char*) (out10 + 48)) % plain_modulus_.value(),
                    byte_array_to_integer((u_char*) (out11 + 48)) % plain_modulus_.value(),
                    plain_modulus_);
            v1[1] = add_uint_uint_mod(v1[1], byte_array_to_integer((u_char*) (out12 + 48)) % plain_modulus_.value(),
                    plain_modulus_);

            // Reset a and na bits
            a = get_bit(a_i, (64 - num_bits_ + i + 1));
            na = a ^ 1u;

            // Redefine aStart and naStart based on new a's
            uint64_t naStart = 48 * na;

            // cs
            for (size_t j = 0; j < 16; j++)
            {
                cs[j] = out0[naStart + j] ^ out1[naStart + j];
            }

            // ct0
            ct0 = out0[96] ^ out1[96] ^ a ^ 1;
            ct1 = out0[97] ^ out1[97] ^ a;

            // cv
            cv0 = sub_uint_uint_mod(
                    sub_uint_uint_mod(v0[0], v1[0], plain_modulus_),
                    multiply_uint_uint_mod(b_i, a, plain_modulus_),
                    plain_modulus_);

            if (t0)
            {
                cv0 = negate_uint_mod(cv0, plain_modulus_);
            }

            cv1 = sub_uint_uint_mod(v0[1], v1[1], plain_modulus_);
            if (t0)
            {
                cv1 = negate_uint_mod(cv1, plain_modulus_);
            }

            // Copy appropriate values into key
            memcpy(k0.cw[i].cs, cs, 48);
            k0.cw[i].ct[0] = ct0;
            k0.cw[i].ct[1] = ct1;

            k0.cw[i].cv[0] = cv0;
            k0.cw[i].cv[1] = cv1;

            memcpy(k1.cw[i].cs, cs, 48);
            k1.cw[i].ct[0] = ct0;
            k1.cw[i].ct[1] = ct1;

            k1.cw[i].cv[0] = cv0;
            k1.cw[i].cv[1] = cv1;

            u_char* rs;
            if (a)
            {
                // update s0
                rs = (u_char*) (out0 + 48);
                for (size_t j = 0; j < 48; j++)
                {
                    s0[j] = rs[j] ^ (cs[j] * t0);
                }
                rs = (u_char*) (out1 + 48);
                for (size_t j = 0; j < 48; j++)
                {
                    s1[j] = rs[j] ^ (cs[j] * t1);
                }
                // update  t0 and t1
                t0 = out0[97] ^ (ct1 * t0);
                t1 = out1[97] ^ (ct1 * t1);
            }
            else
            {
                rs = (u_char*) (out0);
                for (size_t j = 0; j < 48; j++)
                {
                    s0[j] = rs[j] ^ (cs[j] * t0);
                }
                rs = (u_char*) (out1);
                for (size_t j = 0; j < 48; j++)
                {
                    s1[j] = rs[j] ^ (cs[j] * t1);
                }
                t0 = out0[96] ^ (ct0 * t0);
                t1 = out1[96] ^ (ct0 * t1);
            }
        }
    }
#endif
}
