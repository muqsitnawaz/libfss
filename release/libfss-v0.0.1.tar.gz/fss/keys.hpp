
#pragma once

#include <vector>

namespace fss {
    struct DIFCW {
        u_char cs[16];
        u_char ct[2];
        uint64_t cv[2];
    };

    struct DPFCW {
        u_char cs[16];
        u_char ct[2];
    };

    struct DIFKey {
        u_char s[16];
        u_char t;
        std::vector<DIFCW> cw;
    };

    struct DPFKey {
        u_char s[16];
        uint64_t cw_last;
        std::vector<DPFCW> cw;
    };

    struct ReLUKey {
        ReLUKey() = default;

        DIFKey f[3], g[3];
        uint64_t r = 0; // r stores the random mask to blind the input
    };

    struct SplineKey {
        SplineKey() = default;

        DIFKey f[8], g[8];
        uint64_t r = 0;
    };

    struct Max2Key {
        Max2Key() = default;

        DIFKey f1[3], g1[3];
        DIFKey f2[3], g2[3];
        DIFKey f3[3], g3[3];
        DPFKey f[4];
        uint64_t r1 = 0;
        uint64_t r2 = 0;
        uint64_t r = 0;
    };

    struct MaxPoolKey {
        MaxPoolKey() = default;

        std::vector<Max2Key> f;
        std::vector<uint64_t> r;
        uint64_t pool_size = 0;
    };

    struct ArgmaxKey {
        ArgmaxKey() = default;

        std::vector<DPFKey> last_layer;
        MaxPoolKey maxpool_key;
    };

#ifdef FSS_ENABLE_MPC
    struct DIFCWMPC
    {
        u_char cs[48];
        u_char ct[2];
        uint64_t cv[2];
    };

    struct DPFCWMPC
    {
        u_char cs[48];
        u_char ct[2];
    };

    struct DIFKeyMPC
    {
        u_char s[48];
        u_char t;
        std::vector<DIFCWMPC> cw;
    };

    struct DPFKeyMPC
    {
        u_char s[48];
        uint64_t cw_last;
        std::vector<DPFCWMPC> cw;
    };

    struct ReLUKeyMPC
    {
        ReLUKeyMPC() = default;

        DIFKeyMPC f[3], g[3];
        uint64_t r = 0;
    };

    struct SplineKeyMPC
    {
        SplineKeyMPC() = default;

        DIFKeyMPC f[8], g[8];
        uint64_t r = 0;
    };
#endif
}